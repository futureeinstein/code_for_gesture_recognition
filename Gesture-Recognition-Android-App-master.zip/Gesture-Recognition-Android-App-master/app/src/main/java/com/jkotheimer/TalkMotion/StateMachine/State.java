package com.jkotheimer.TalkMotion.StateMachine;

public interface State {
    void x_move();
    void y_move();
    void z_move();
}
